package com.mie.dao;

public class PasswordMismatchException extends Exception {

}
