package com.mie.model;

public class Trip {

}
