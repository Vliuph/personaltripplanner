package com.mie.model;

public class TripDay {

}
