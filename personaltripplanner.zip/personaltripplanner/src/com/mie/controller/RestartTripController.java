package com.mie.controller;

import javax.servlet.http.HttpServlet;

public class RestartTripController extends HttpServlet {

}
